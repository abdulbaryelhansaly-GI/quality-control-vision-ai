import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, ReduceLROnPlateau
from sklearn.metrics import classification_report, confusion_matrix
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
from model import build_model, unfreeze_top_layers

DATA_DIR    = "data/processed"
IMG_SIZE    = (224, 224)
BATCH_SIZE  = 32
EPOCHS_P1   = 15
EPOCHS_P2   = 10
MODEL_PATH  = "models/quality_control_best.h5"


def get_generators():
    train_gen = ImageDataGenerator(
        rescale=1./255,
        rotation_range=20,
        width_shift_range=0.1,
        height_shift_range=0.1,
        horizontal_flip=True,
        vertical_flip=True,
        zoom_range=0.15,
        validation_split=0.2
    )
    val_gen = ImageDataGenerator(rescale=1./255, validation_split=0.2)

    train_data = train_gen.flow_from_directory(
        DATA_DIR, target_size=IMG_SIZE, batch_size=BATCH_SIZE,
        class_mode='categorical', subset='training', shuffle=True
    )
    val_data = val_gen.flow_from_directory(
        DATA_DIR, target_size=IMG_SIZE, batch_size=BATCH_SIZE,
        class_mode='categorical', subset='validation', shuffle=False
    )

    # ✅ Fix déséquilibre des classes
    total = 229 + 63
    class_weight = {
        0: total / (2 * 63),   # defective → plus de poids
        1: total / (2 * 229)   # good → moins de poids
    }
    print("Class weights:", class_weight)

    return train_data, val_data, class_weight

def get_callbacks():
    return [
        ModelCheckpoint(MODEL_PATH, save_best_only=True, monitor='val_accuracy', verbose=1),
        EarlyStopping(patience=5, restore_best_weights=True, monitor='val_accuracy'),
        ReduceLROnPlateau(factor=0.3, patience=3, min_lr=1e-7, verbose=1)
    ]


def train():
    train_data, val_data, class_weight = get_generators()
    model, base_model = build_model()

    print("\n=== Phase 1 : Entraînement de la tête ===")
    model.compile(
        optimizer=tf.keras.optimizers.Adam(1e-3),
        loss='categorical_crossentropy',
        metrics=['accuracy']
    )
    history1 = model.fit(
        train_data, validation_data=val_data,
        epochs=EPOCHS_P1, callbacks=get_callbacks(),
        class_weight=class_weight   # ✅ ajouté ici
    )

    print("\n=== Phase 2 : Fine-tuning ===")
    unfreeze_top_layers(base_model, num_layers=20)
    model.compile(
        optimizer=tf.keras.optimizers.Adam(1e-5),
        loss='categorical_crossentropy',
        metrics=['accuracy']
    )
    history2 = model.fit(
        train_data, validation_data=val_data,
        epochs=EPOCHS_P2, callbacks=get_callbacks(),
        class_weight=class_weight   # ✅ ajouté ici
    )

    return model, history1, history2, val_data

def evaluate(model, val_data):
    val_data.reset()
    preds = model.predict(val_data, verbose=1)
    y_pred = np.argmax(preds, axis=1)
    y_true = val_data.classes
    labels = list(val_data.class_indices.keys())

    print("\n=== Rapport de classification ===")
    print(classification_report(y_true, y_pred, target_names=labels))

    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=labels, yticklabels=labels)
    plt.title("Matrice de confusion")
    plt.ylabel("Réel"); plt.xlabel("Prédit")
    plt.tight_layout()
    plt.savefig("outputs/confusion_matrix.png", dpi=150)
    plt.show()


def plot_history(h1, h2):
    acc  = h1.history['accuracy'] + h2.history['accuracy']
    val  = h1.history['val_accuracy'] + h2.history['val_accuracy']
    loss = h1.history['loss'] + h2.history['loss']
    epochs = range(1, len(acc) + 1)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))
    ax1.plot(epochs, acc, label='Train')
    ax1.plot(epochs, val, label='Validation')
    ax1.axvline(EPOCHS_P1, color='red', linestyle='--', label='Fine-tuning start')
    ax1.set_title('Accuracy'); ax1.legend()
    ax2.plot(epochs, loss, label='Train Loss')
    ax2.set_title('Loss'); ax2.legend()

    plt.tight_layout()
    plt.savefig("outputs/training_history.png", dpi=150)
    plt.show()


if __name__ == "__main__":
    os.makedirs("models", exist_ok=True)
    os.makedirs("outputs", exist_ok=True)
    model, h1, h2, val_data = train()
    evaluate(model, val_data)
    plot_history(h1, h2)
